

SELECT Login_name_user_hdr,
       CASE 
	       WHEN DATEPART(WEEKDAY, GETDATE()) = 2  
                --AND DATEDIFF(DAY, Modified_date_user_hdr, GETDATE()) > 30  -- More than 30 days since last password change
           THEN 'ALERT: Please change your password It is monday Today'
           
           WHEN DATEDIFF(DAY, b.[Modified_Date], GETDATE()) > 30--DATEPART(WEEKDAY, GETDATE()) = 2  
                --AND DATEDIFF(DAY, Modified_date_user_hdr, GETDATE()) > 30  -- More than 30 days since last password change
           THEN begin select 'ALERT: Please change your password IT HAS EXCEED MORE THAN 30 DAYS',DATEDIFF(DAY, b.[Modified_Date], GETDATE())'number or days'
		   end
           
           WHEN DATEPART(WEEKDAY, GETDATE()) <> 2  
                AND DATEDIFF(DAY,b.[Modified_Date], GETDATE()) > 7  -- More than 7 days since last password change
           THEN 'ALERT: Your password needs to be changed soon IT HAS BEEN MORE THAN SEVEN DAYS'
           
           ELSE 'Password is up to date'
       END AS password_status
FROM [ERP].[gmtmaster].[tbl_user_info_hdr] a
inner join [ERP].[gmtmaster].[tbl_Change_Password_Log]  b on a.Login_name_user_hdr = b.[User_Name]
WHERE Password_user_hdr = 'asmg549870'
--select Modified_date_user_hdr  FROM [ERP].[gmtmaster].[tbl_user_info_hdr]  where  Password_user_hdr = 'asmg549870'
--select [Modified_Date] from [ERP].[gmtmaster].[tbl_Change_Password_Log] where [User_Name] ='Angel'

--REL/RCKT/23-24/DOE/215
--  REL/RCKT/23-24/DOE/225
--  REL/RCKT/23-24/GRN/853
--  REL/RCKT/23-24/GRN/864
--REL/RCKT/23-24/DOE/233
--REL/RCKT/23-24/DOE/263

SELECT TOP (1000) [Sno]
      ,[User_Name]
      ,[Old_Password]
      ,[New_Password]
      ,[Reason]
      ,[status_entry]
      ,[Created_by]
      ,[Created_Date]
      ,[Created_Mac_Address]
      ,[Modified_by]
      ,[Modified_Date]
      ,[Modified_Mac_Address]
  FROM [ERP].[gmtmaster].[tbl_Change_Password_Log] where [User_Name] ='Angel'

