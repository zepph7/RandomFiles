select 
row_number() over(order by (select 1)) 'Sno',
replace(convert(varchar(50),a.CREATED_DATE,106),' ','-')'Sales Date' ,
convert(varchar(50),a.CREATED_DATE,108) 'Time' ,Sub_Category_Name'Category' ,Product_Name 'product' ,cast(sum(TOTAL_QTY) as  int) Qty 
from  StoEntries .TBL_LOCAL_SALES_DTL a
left join stomaster.tbl_Product_Sub_Category_Master s on a.SUB_CATEGORY_ID =s.Sub_Category_Id 
left join stomaster.tbl_Product_Master p on a.PRODUCT_ID  =p.Product_Id  
where a.CREATED_DATE between '2024-09-28'+' 00:00:00.00' and '2024-09-28'+' 23:59:00.00'
group by replace(convert(varchar(50),a.CREATED_DATE,106),' ','-')
,convert(varchar(50),a.CREATED_DATE,108),Sub_Category_Name  ,Product_Name 

