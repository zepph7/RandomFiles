SELECT a.Login_name_user_hdr,
       CASE 
           WHEN DATEPART(WEEKDAY, GETDATE()) = 2  
           THEN 'ALERT: Please change your password It is Monday Today'
           
           WHEN DATEDIFF(DAY, b.[Modified_Date], GETDATE()) > 30  
           THEN 'ALERT: Please change your password IT HAS EXCEEDED MORE THAN 30 DAYS'
           
           WHEN DATEPART(WEEKDAY, GETDATE()) <> 2  
                AND DATEDIFF(DAY, b.[Modified_Date], GETDATE()) > 7  
           THEN 'ALERT: Your password needs to be changed soon IT HAS BEEN MORE THAN SEVEN DAYS'
           
           ELSE 'Password is up to date'
       END AS password_status,
       DATEDIFF(DAY, b.[Modified_Date], GETDATE()) AS 'number_of_days_since_last_change',b.[Modified_Date]
FROM [ERP].[gmtmaster].[tbl_user_info_hdr] a
INNER JOIN [ERP].[gmtmaster].[tbl_Change_Password_Log] b 
    ON a.Login_name_user_hdr = b.[User_Name]
WHERE a.Password_user_hdr = 'asmg549870';
