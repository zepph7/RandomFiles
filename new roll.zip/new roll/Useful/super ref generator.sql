declare  @KeyCharCode varchar(5)= 'OSD',@KeyCharCode1 varchar(5)= 'SCI',@Year varchar(10)='',@Month varchar(10) ='',@Full_Short_Code varchar(50)=''
,@Invoice_Ref_No  varchar(50)='',@Invo_Type varchar(20)='SALES COMMISSION',@CurDate datetime=getdate()
set @Month =datepart(Month,@CurDate)
set @Year = datename(year,@CurDate)
IF @Invo_Type = 'COMMERCIAL INVOICE'
set @Full_Short_Code=@KeyCharCode+'-'+iif(@Month<=9,'0'+@month,@Month)+'-'+@Year+'-'
else
set @Full_Short_Code=@KeyCharCode1+'-'+iif(@Month<=9,'0'+@month,@Month)+'-'+@Year+'-'
declare @Auto_increment_ID varchar(15)='' 
set @Invoice_Ref_No = @Full_Short_Code


if exists(select  'already exists checking'
From Reliable.Rentries.TBL_SALES_PROFORMA_INVOICE_HDR 
where  PROFORMA_REF_NO  like '%-'+@Year+'-%' --order by sno desc
)
begin

select  top 1 @Auto_increment_ID=isNull(cast(RIGHT(Tax_Invoice_Ref_No , CHARINDEX ('-' ,REVERSE(Tax_Invoice_Ref_No))-1) as int),0) 
From Reliable.Rentries.tbl_Tax_Invoice_Hdr  
where  Tax_Invoice_Ref_No  like '%-'+@Year+'-%' order by sno desc
end
else
begin
       set @Auto_increment_ID=0
end
set @Auto_increment_ID =cast(@Auto_increment_ID as int)+ 1

if @Auto_increment_ID=1 AND @Year=2024 --- INITIAL YEAR
begin
set @Auto_increment_ID =187
end

set  @Invoice_Ref_No=@Full_Short_Code+@Auto_increment_ID

select  @Invoice_Ref_No